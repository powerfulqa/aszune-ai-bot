// Simple test to make the file valid as a test suite
describe('Discord mock module', () => {
  test('Mock is valid', () => {
    expect(true).toBe(true);
  });
});
